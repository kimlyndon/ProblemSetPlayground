/*:
 
 ## Swift Problem Set
 
 This playground contains a series of problems covering variables, strings, if (else-if and else) statements, and functions.
 
 - [Variables](Variables)
 - [Strings](Strings)
 - [If Statements](If%20Statements)
 - [Functions](Functions)
 - [(Optional) Challenge](Challenge)
 
 ****
 [Next](@next)
 */
